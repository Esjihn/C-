﻿
namespace XamarinCRM.Models.Local
{
    public class CategorySalesDataPoint
    {
        public string CategoryName { get; set; }

        public double Amount { get; set; }
    }
}

