﻿using System.Collections.Generic;

namespace iText5_Sample
{
    public class ElectionOptions
    {
        public bool DisplayDetailResults { get; set; }
        public List<string> VoteTypesUsed { get; set; }
    }
}
 