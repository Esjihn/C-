﻿namespace iText5_Sample
{
    public class Precinct
    {
    }
}
