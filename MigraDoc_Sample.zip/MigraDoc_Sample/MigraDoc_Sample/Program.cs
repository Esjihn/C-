﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Web.UI.WebControls;
using System.Xml.XPath;
using Microsoft.VisualBasic.FileIO;
using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using PdfSharp.Pdf;
using BorderStyle = MigraDoc.DocumentObjectModel.BorderStyle;
using Orientation = MigraDoc.DocumentObjectModel.Orientation;
using PageSetup = MigraDoc.DocumentObjectModel.PageSetup;
using Table = MigraDoc.DocumentObjectModel.Tables.Table;


namespace MigraDoc_Sample
{
    class Program
    {
        static readonly ReportRecord Rr = new ReportRecord();

        static void Main(string[] args)
        {
            // Create a MigraDoc document
            Document document = CreateDocument();

            // Turn page into landscape. 
            PageSetup pageSetup = document.DefaultPageSetup;
            pageSetup.Orientation = Orientation.Landscape;

            document.UseCmykColor = true;
            // ====== Unicode encoding and font program embedding in MigraDoc is demonstrated here =====

            // A flag indicating whether to create a Unicode PDF or a WinAnsi PDF file.
            // This setting applies to all fonts used in the PDF document.
            // This setting has no effect on the RTF renderer.
            const bool unicode = false;
            
            // Create a renderer for the MigraDoc document.
            PdfDocumentRenderer pdfRenderer = new PdfDocumentRenderer(unicode) {Document = document};

            // Layout an render document to PDF
            pdfRenderer.RenderDocument();

            // Save the document....
            const string filename = @"Data\PdfTest.pdf";
            pdfRenderer.PdfDocument.Save(filename);

            // ...and start a viewer.
            Process.Start(filename);
        }

        public static Document CreateDocument()
        {
            // Create a new MigraDoc Document
            Document document = new Document();

            // Add a section to the document
            Section section = document.AddSection();

            var readPath = @"Data\CandidateSummaryResults_2018-10-16T13_17_09.csv";
            
            using (TextFieldParser csvParser = new TextFieldParser(readPath))
            {
                csvParser.CommentTokens = new[] { "#" }; // string
                csvParser.SetDelimiters(",");
                csvParser.HasFieldsEnclosedInQuotes = true;

                // Skip the row with the column names
                csvParser.ReadLine();
                
                bool isGrey = true;

                // TODO check
                var headerTable = section.AddTable();
                CreateHeaderTableFormat(headerTable);
                
                while (!csvParser.EndOfData)
                {
                    // Read current line fields, pointer moves to the next line.
                    string[] fields = csvParser.ReadFields();

                    if (fields != null)
                    {   
                        Rr.ContestId = fields[0];
                        Rr.Contest = fields[1];
                        Rr.CandidateIssueId = fields[2];
                        Rr.CandidateIssue = fields[3];
                        Rr.Party = fields[4];
                        Rr.TotalVotes = fields[5];
                        Rr.VotePercent = fields[6];

                        int counter = 0;

                        foreach (var field in fields)
                        {
                            counter++;
                            if (counter % 6 == 0)
                            {
                                var table = section.AddTable();
                                CreateMainTableFormat(table, ref isGrey);
                            }
                        }
                    }
                }
            }
            return document;
        }

        public static Table CreateHeaderTableFormat(Table table)
        {
            table.AddColumn();
            table.Style = "Header Table";

            table.Borders.Width = 0.25;
            table.Borders.Left.Width = 0.5;
            table.Borders.Right.Width = 0.5;
            table.Rows.LeftIndent = 0;

            // Before you can add a row, you must define the columns
            Column headerColumn = table.AddColumn("3cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Center;
            headerColumn = table.AddColumn("4cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Right;
            headerColumn = table.AddColumn("4cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Right;
            headerColumn = table.AddColumn("2cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Right;
            headerColumn = table.AddColumn("2cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Center;
            headerColumn = table.AddColumn("4cm");
            headerColumn.Format.Alignment = ParagraphAlignment.Right;

            var headerRow = table.AddRow();
            headerRow.Cells[0].AddParagraph("Contest ID");
            headerRow.Cells[0].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[1].AddParagraph("Contest");
            headerRow.Cells[1].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[2].AddParagraph("Candidate");
            headerRow.Cells[2].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[4].AddParagraph("Party");
            headerRow.Cells[4].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[3].AddParagraph("Candidate Issue");
            headerRow.Cells[3].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[5].AddParagraph("Total Votes");
            headerRow.Cells[5].Format.Alignment = ParagraphAlignment.Left;
            headerRow.Cells[6].AddParagraph("% of Total Votes");
            headerRow.Cells[6].Format.Alignment = ParagraphAlignment.Left;

            table.SetEdge(0, 0, 1, 1, Edge.Box, BorderStyle.Single, 0.75, Color.Empty);

            return table;
        }

        public static Table CreateMainTableFormat(Table table, ref bool isGrey)
        {
            table.AddColumn();
            table.Style = "Table";
            table.Borders.Width = 0.25;
            table.Borders.Left.Width = 0.5;
            table.Borders.Right.Width = 0.5;
            table.Rows.LeftIndent = 0;

            // Before you can add a row, you must define the columns
            Column column = table.AddColumn("3cm");
            column.Format.Alignment = ParagraphAlignment.Center;
            column = table.AddColumn("4cm");
            column.Format.Alignment = ParagraphAlignment.Right;
            column = table.AddColumn("4cm");
            column.Format.Alignment = ParagraphAlignment.Right;
            column = table.AddColumn("2cm");
            column.Format.Alignment = ParagraphAlignment.Right;
            column = table.AddColumn("2cm");
            column.Format.Alignment = ParagraphAlignment.Center;
            column = table.AddColumn("4cm");
            column.Format.Alignment = ParagraphAlignment.Right;

            var row = table.AddRow();
            row.HeadingFormat = true;
            row.Format.Alignment = ParagraphAlignment.Center;
            row.Format.Font.Bold = true;

            if (isGrey)
                row.Shading.Color = Color.FromRgbColor(40, Colors.DarkSlateGray);

            isGrey = !isGrey;

            row.Cells[0].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[0].AddParagraph(Rr.ContestId);

            row.Cells[1].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[1].AddParagraph(Rr.Contest);

            row.Cells[2].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[2].AddParagraph(Rr.CandidateIssueId);

            row.Cells[3].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[3].AddParagraph(Rr.CandidateIssue);

            row.Cells[4].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[4].AddParagraph(Rr.Party);

            row.Cells[5].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[5].AddParagraph(Rr.TotalVotes);

            row.Cells[6].Format.Alignment = ParagraphAlignment.Left;
            row.Cells[6].AddParagraph(Rr.VotePercent);

            table.SetEdge(0, 0, 4, 1, Edge.Box, BorderStyle.Single, 0.75, Color.Empty);

            return table;
        }
    
    }
}






