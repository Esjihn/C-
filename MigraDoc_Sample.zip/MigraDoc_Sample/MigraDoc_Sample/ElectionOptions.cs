﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigraDoc_Sample
{
    public class ElectionOptions
    {
        public bool DisplayDetailResults { get; set; }
        public List<string> VoteTypesUsed { get; set; }
    }
}
 