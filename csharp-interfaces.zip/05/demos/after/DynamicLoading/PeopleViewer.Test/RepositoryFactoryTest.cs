﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PeopleViewer.Test
{
    [TestClass]
    public class RepositoryFactoryTest
    {
    }
}
