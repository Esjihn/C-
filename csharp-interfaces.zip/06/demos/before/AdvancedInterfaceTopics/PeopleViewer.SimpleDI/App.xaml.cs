﻿using PersonRepository.Fake;
using PersonRepository.Interface;
using System.Windows;

namespace PeopleViewer
{
    public partial class App : Application
    {
    }
}
