﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PersonRepository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PeopleViewer.Test
{
    [TestClass]
    public class MockVMTest
    {
    }
}
