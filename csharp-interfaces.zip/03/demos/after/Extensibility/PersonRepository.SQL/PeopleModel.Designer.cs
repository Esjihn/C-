﻿// Default code generation is disabled for model 'C:\Development\Pluralsight\Interfaces\Module 3 - Creating Interfaces to Add Extensibility\demos\after\Extensibility\PersonRepository.SQL\PeopleModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.